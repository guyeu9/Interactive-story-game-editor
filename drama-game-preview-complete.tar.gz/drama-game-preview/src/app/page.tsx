'use client';

import React from 'react';
import DramaGameComponent from '@/components/DramaGameComponent';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-900">剧情游戏编辑器预览</h1>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">React Component Preview</span>
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-4">
              <h2 className="text-lg font-semibold">剧情织造机 (Text Game Weaver) V1.3.19</h2>
              <p className="text-sm opacity-90 mt-1">交互式剧情游戏编辑器 - 完整功能预览</p>
            </div>
            
            <div className="p-0">
              <div className="border-t">
                <DramaGameComponent />
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-white border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500">
            剧情游戏编辑器预览界面 | 基于 Next.js 构建
          </p>
        </div>
      </footer>
    </div>
  );
}