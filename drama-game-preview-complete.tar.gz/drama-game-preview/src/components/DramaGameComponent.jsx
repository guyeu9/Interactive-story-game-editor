import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Layers, 
  Zap, 
  Play, 
  Settings, 
  Plus, 
  Trash2, 
  Edit3, 
  Download, 
  Upload, 
  FileText,
  X,
  ListPlus,
  History,
  HardDrive,
  AlertTriangle,
  MapPin,
  Save,
  Copy, 
  Check, 
  Link, 
  Share2, 
  MessageSquare 
} from 'lucide-react';

/**
 * ------------------------------------------------------------------
 * 剧情织造机 (Text Game Weaver) V1.3.19 (定制版)
 * 更新日志：
 * - [修复] 模态框层级：修复点击历史记录删除按钮时，删除确认模态框被历史记录模态框遮挡的问题。
 * - [优化] Modal 组件：增加 zIndex 属性，允许灵活控制层级。
 * ------------------------------------------------------------------
 */

// --- 辅助组件：导航按钮 ---
const NavButton = ({ icon: Icon, label, active, onClick, primary }) => (
  <button
    onClick={onClick}
    className={`flex flex-col items-center justify-center w-14 transition-colors ${
      primary
        ? 'text-indigo-600 font-bold -mt-4 bg-indigo-50 rounded-full h-14 w-14 border border-indigo-100 shadow-lg'
        : active ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
    }`}
  >
    <Icon size={primary ? 24 : 20} strokeWidth={active || primary ? 2.5 : 2} />
    {!primary && <span className="text-[10px] mt-1 font-medium">{label}</span>}
  </button>
);

// --- 初始演示数据 ---
const INITIAL_LAYERS = [
  { layer_id: "L1_SETUP", layer_name: "开场准备", sequence: 1 },
  { layer_id: "L2_CORE", layer_name: "核心解谜", sequence: 2 },
  { layer_id: "L3_ENDING", layer_name: "结局判定", sequence: 3 }
];

const INITIAL_SCENES = [
  { id: "S001", name: "废弃实验室", description: "充满灰尘和化学试剂味道的房间。", tags: ["恐怖", "解谜", "室内"] },
  { id: "S002", name: "中央公园", description: "阳光明媚，但似乎隐藏着危机。", tags: ["开放", "日间", "NPC"] }
];

const INITIAL_PLAYS = [
  { id: "P001", name: "搜寻物资", description: "在角落里翻找，发现了一个急救包。", trigger_condition: "无", result: "获得急救包", fk_layer_id: "L1_SETUP", tags: ["生存"] },
  { id: "P002", name: "破解密码锁", description: "玩家需要找到并破解一个三位密码锁。", trigger_condition: "进入实验室", result: "获得核心线索", fk_layer_id: "L2_CORE", tags: ["解谜", "室内"] },
  { id: "P003", name: "遭遇野狗", description: "一只野狗挡住了去路。", trigger_condition: "无", result: "战斗或逃跑", fk_layer_id: "L2_CORE", tags: ["开放", "战斗"] },
  { id: "P004", name: "逃出生天", description: "成功找到了出口。", trigger_condition: "线索集齐", result: "游戏胜利", fk_layer_id: "L3_ENDING", tags: ["结局"] }
];

const INITIAL_COMMANDS = [
  { id: "C001", name: "突发地震", description: "地面剧烈摇晃，物品掉落。", probability: 30, scope_type: "LAYER", fk_target_id: "L2_CORE" },
  { id: "C002", name: "NPC提供线索", description: "一个流浪汉提供了关键信息。", probability: 50, scope_type: "SCENE", fk_target_id: "S002" },
  { id: "C003", name: "天气突变", description: "突然下起了暴雨。", probability: 10, scope_type: "GLOBAL", fk_target_id: "" }
];

// --- 辅助组件：Card, Badge, Button, Modal, Snackbar ---

const Card = ({ children, className = "", onClick }) => (
  // 确保 Card 组件支持 onClick 属性
  <div onClick={onClick} className={`bg-white rounded-xl shadow-sm border border-slate-100 p-4 mb-3 ${className}`}>
    {children}
  </div>
);

const Badge = ({ children, color = "blue", className = "" }) => {
  const colors = {
    blue: "bg-blue-50 text-blue-700 border-blue-100",
    green: "bg-emerald-50 text-emerald-700 border-emerald-100",
    purple: "bg-purple-50 text-purple-700 border-purple-100",
    orange: "bg-orange-50 text-orange-700 border-orange-100",
    slate: "bg-slate-100 text-slate-600 border-slate-200",
  };
  return (
    <span className={`px-2 py-0.5 rounded-md text-xs font-medium border ${colors[color] || colors.slate} mr-1 ${className}`}>
      {children}
    </span>
  );
};

const Button = ({ children, onClick, variant = "primary", className = "", size = "md", disabled = false, type = "button" }) => {
  const base = "flex items-center justify-center rounded-lg font-medium transition-colors active:scale-95";
  const variants = {
    primary: "bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm shadow-indigo-200",
    secondary: "bg-white text-slate-700 border border-slate-200 hover:bg-slate-50",
    danger: "bg-red-500 text-white hover:bg-red-600 shadow-sm shadow-red-200",
    ghost: "text-slate-500 hover:bg-slate-100",
    lightDanger: "bg-red-50 text-red-600 border border-red-100 hover:bg-red-100",
  };
  const sizes = {
    sm: "px-2 py-1 text-xs",
    md: "px-4 py-2 text-sm",
    lg: "px-6 py-3 text-base w-full",
    icon: "p-2",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${base} ${variants[variant]} ${sizes[size]} ${className} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {children}
    </button>
  );
};

// V1.3.19 修复：Modal 组件增加 zIndex 属性，用于控制层级，解决遮挡问题。
const Modal = ({ isOpen, onClose, title, children, zIndex = 50 }) => {
  if (!isOpen) return null;
  // zIndex 用于背景遮罩，zIndex + 1 用于内容容器，确保内容比背景高一层
  const bgZ = zIndex; 
  const contentZ = zIndex + 1; 

  return (
    <div 
      className={`fixed inset-0 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-in fade-in duration-200`} 
      style={{ zIndex: bgZ }}
    >
      <div 
        className="bg-white rounded-2xl w-full max-w-lg shadow-xl max-h-[90vh] overflow-y-auto flex flex-col"
        style={{ zIndex: contentZ }}
      >
        <div className="flex justify-between items-center p-4 border-b border-slate-100 sticky top-0 bg-white z-10">
          <h3 className="text-lg font-bold text-slate-800">{title}</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-full text-slate-500">
            <X size={20} />
          </button>
        </div>
        <div className="p-4 space-y-4">
          {children}
        </div>
      </div>
    </div>
  );
};

const Snackbar = ({ message, type = "success", onClose }) => {
  if (!message) return null;
  const bg = type === "error" ? "bg-red-600" : "bg-slate-800";
  return (
    <div className={`fixed bottom-20 left-4 right-4 ${bg} text-white px-4 py-3 rounded-lg shadow-lg z-50 flex items-center justify-between animate-in slide-in-from-bottom-5 duration-300`}>
      <span className="text-sm font-medium">{message}</span>
      <button onClick={onClose} className="text-white/80 hover:text-white"><X size={16}/></button>
    </div>
  );
};

// --- 辅助组件：多选框列表 ---
const CheckboxList = ({ name, options, selectedValues, onChange, required = false }) => {
  // 内部状态用于管理复选框的选中状态
  const [localSelected, setLocalSelected] = useState(selectedValues);

  const handleCheck = (id) => {
    const newSelection = localSelected.includes(id)
      ? localSelected.filter(v => v !== id)
      : [...localSelected, id];
    
    setLocalSelected(newSelection);
    // 通过回调通知父组件更新其状态
    onChange(newSelection);
  };

  // 确保外部状态变化时，内部状态能同步更新 (用于编辑时)
  useEffect(() => {
    // 确保 selectedValues 是一个数组
    if (Array.isArray(selectedValues)) {
        setLocalSelected(selectedValues);
    }
  }, [selectedValues]);


  return (
    <div 
      className="w-full border border-slate-300 rounded-lg p-2 h-40 overflow-y-auto bg-white"
    >
      {required && localSelected.length === 0 && (
          <p className="text-xs text-red-500 mb-2">请至少选择一项</p>
      )}
      {options.length === 0 ? (
          <p className="text-center text-sm text-slate-400 py-4">暂无可选 {name} 数据</p>
      ) : options.map(opt => (
        <div key={opt.id} className="flex items-center text-sm cursor-pointer hover:bg-slate-50 p-1 rounded">
          <input
            type="checkbox"
            id={`${name}-${opt.id}`}
            // 不在 input 上使用 name 属性，而是依赖 onChange 更新父状态，以避免 FormData 的复杂性
            value={opt.id}
            checked={localSelected.includes(opt.id)}
            onChange={() => handleCheck(opt.id)}
            className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500 mr-2 flex-shrink-0"
          />
          <label htmlFor={`${name}-${opt.id}`} className="text-slate-700 select-none flex-1 leading-tight">
            {opt.name}
          </label>
        </div>
      ))}
    </div>
  );
};

// --- 主应用组件 ---
export default function TextGameApp() {
  // --- 状态管理 ---
  const [activeTab, setActiveTab] = useState("generator");

  const [scenes, setScenes] = useState(INITIAL_SCENES);
  const [layers, setLayers] = useState(INITIAL_LAYERS);
  const [plays, setPlays] = useState(INITIAL_PLAYS);
  const [commands, setCommands] = useState(INITIAL_COMMANDS);

  // V1.3 新增：历史生成记录
  // history item: { timestamp, sceneName, story }
  const [generatedHistory, setGeneratedHistory] = useState([]);

  // UI 交互状态
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("add"); // add | edit | batch | history | confirm
  const [editingItem, setEditingItem] = useState(null);
  const [targetType, setTargetType] = useState("scene"); // scene | layer | play | command | history
  const [toast, setToast] = useState({ msg: "", type: "success" });

  // V1.3 修复: 删除确认状态 (取代 window.confirm)
  const [confirmingDelete, setConfirmingDelete] = useState(null); // { id, type, name }

  // V1.3.2 新增: 复制状态
  const [copiedId, setCopiedId] = useState(null);

  // V1.3.16 新增: 历史记录标题编辑状态
  const [editingHistoryId, setEditingHistoryId] = useState(null); 
  const [tempHistoryTitle, setTempHistoryTitle] = useState('');

  // 生成器状态
  const [selectedSceneId, setSelectedSceneId] = useState("");
  const [generatedStory, setGeneratedStory] = useState([]);
  
  // V1.3.7 状态: 用于指令编辑表单
  const [commandScopeType, setCommandScopeType] = useState("GLOBAL"); 
  // V1.3.7 关键状态：用于管理多选框列表的选中值 (SCENE/LAYER)
  const [commandTargetIds, setCommandTargetIds] = useState([]); 

  const [batchText, setBatchText] = useState("");

  // [新增] 批量导入玩法目标层级
  const [batchLayerId, setBatchLayerId] = useState(INITIAL_LAYERS[0]?.layer_id || "");

  // [V1.3.9 新增] 批量导入指令默认作用域
  const [batchCommandScope, setBatchCommandScope] = useState('GLOBAL'); 
  
  // [V1.3.12 关键新增] 批量导入指令默认目标ID (数组，用于 CheckboxList)
  const [batchCommandTargetIdsArray, setBatchCommandTargetIdsArray] = useState([]);

  // 新增：剧情走向模式状态
  const [interactiveMode, setInteractiveMode] = useState(false);
  const [interactiveStory, setInteractiveStory] = useState([]);
  const [currentLayerIndex, setCurrentLayerIndex] = useState(0);
  const [selectedChoices, setSelectedChoices] = useState([]);
  const [selectedCommands, setSelectedCommands] = useState([]);
  const [currentScene, setCurrentScene] = useState(null);

  // 新增：数据保存相关状态
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaveTime, setLastSaveTime] = useState(null);

  // 加强版数据持久化机制
  const STORAGE_KEYS = {
    scenes: 'tg_scenes',
    layers: 'tg_layers', 
    plays: 'tg_plays',
    commands: 'tg_commands',
    history: 'tg_history',
    interactiveMode: 'tg_interactive_mode',
    selectedSceneId: 'tg_selected_scene_id',
    generatedStory: 'tg_generated_story',
    activeTab: 'tg_active_tab'
  };

  // 安全的LocalStorage操作函数
  const safeLocalStorage = {
    get: (key, defaultValue = null) => {
      try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
      } catch (error) {
        console.error(`LocalStorage读取失败 [${key}]:`, error);
        return defaultValue;
      }
    },
    
    set: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
      } catch (error) {
        console.error(`LocalStorage写入失败 [${key}]:`, error);
        // 存储空间满时的处理
        if (error.name === 'QuotaExceededError') {
          showToast("本地存储空间不足，请清理数据", "error");
        }
        return false;
      }
    },
    
    remove: (key) => {
      try {
        localStorage.removeItem(key);
        return true;
      } catch (error) {
        console.error(`LocalStorage删除失败 [${key}]:`, error);
        return false;
      }
    }
  };

  // 数据加载函数（组件初始化时执行）
  const loadPersistedData = () => {
    const loadItem = (key, setter, initialValue) => {
      const saved = safeLocalStorage.get(STORAGE_KEYS[key], initialValue);
      if (saved !== null) {
        // 验证数据格式
        if (Array.isArray(saved) && (key === 'scenes' || key === 'layers' || key === 'plays' || key === 'commands' || key === 'history')) {
          setter(saved);
          console.log(`成功加载 ${key}: ${saved.length} 条数据`);
        } else if (typeof saved === 'string' && (key === 'selectedSceneId' || key === 'activeTab')) {
          setter(saved);
          console.log(`成功加载 ${key}: ${saved}`);
        } else if (typeof saved === 'boolean' && key === 'interactiveMode') {
          setter(saved);
        } else if (Array.isArray(saved) && key === 'generatedStory') {
          setter(saved);
          console.log(`成功加载 ${key}: ${saved.length} 个故事片段`);
        } else {
          console.warn(`${key} 数据格式无效，使用默认值`);
          setter(initialValue);
        }
      } else {
        setter(initialValue);
      }
    };

    // 加载所有持久化数据
    loadItem('scenes', setScenes, INITIAL_SCENES);
    loadItem('layers', setLayers, INITIAL_LAYERS);
    loadItem('plays', setPlays, INITIAL_PLAYS);
    loadItem('commands', setCommands, INITIAL_COMMANDS);
    loadItem('history', setGeneratedHistory, []);
    loadItem('selectedSceneId', setSelectedSceneId, "");
    loadItem('activeTab', setActiveTab, "generator");
    loadItem('generatedStory', setGeneratedStory, []);
    
    // 恢复剧情走向模式（可选）
    const savedInteractiveMode = safeLocalStorage.get(STORAGE_KEYS.interactiveMode, false);
    if (savedInteractiveMode) {
      // 清理剧情走向模式状态，避免异常
      setInteractiveMode(false);
      setCurrentLayerIndex(0);
      setInteractiveStory([]);
      setSelectedChoices([]);
      setSelectedCommands([]);
      setCurrentScene(null);
    }

    setLastSaveTime(Date.now());
    console.log('数据加载完成');
  };

  // 防抖保存函数
  const debouncedSave = (() => {
    let timeoutId = null;
    return (data, key) => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        if (safeLocalStorage.set(STORAGE_KEYS[key], data)) {
          setLastSaveTime(Date.now());
          console.log(`自动保存 ${key} 成功`);
        }
      }, 500); // 500ms防抖延迟
    };
  })();

  // 批量保存所有数据
  const saveAllData = () => {
    if (isSaving) return;
    
    setIsSaving(true);
    const success = {
      scenes: safeLocalStorage.set(STORAGE_KEYS.scenes, scenes),
      layers: safeLocalStorage.set(STORAGE_KEYS.layers, layers),
      plays: safeLocalStorage.set(STORAGE_KEYS.plays, plays),
      commands: safeLocalStorage.set(STORAGE_KEYS.commands, commands),
      history: safeLocalStorage.set(STORAGE_KEYS.history, generatedHistory),
      selectedSceneId: safeLocalStorage.set(STORAGE_KEYS.selectedSceneId, selectedSceneId),
      activeTab: safeLocalStorage.set(STORAGE_KEYS.activeTab, activeTab),
      generatedStory: safeLocalStorage.set(STORAGE_KEYS.generatedStory, generatedStory)
    };

    const allSuccess = Object.values(success).every(Boolean);
    if (allSuccess) {
      setLastSaveTime(Date.now());
      console.log('所有数据保存成功');
    } else {
      showToast("部分数据保存失败", "error");
    }
    
    setIsSaving(false);
    return allSuccess;
  };

  // 清理所有数据
  const clearAllData = () => {
    Object.values(STORAGE_KEYS).forEach(key => {
      safeLocalStorage.remove(key);
    });
    setLastSaveTime(null);
    console.log('所有本地数据已清理');
  };

  // 初始化时加载数据
  useEffect(() => {
    loadPersistedData();
  }, []);

  // 页面卸载时保存数据
  useEffect(() => {
    const handleBeforeUnload = (e) => {
      saveAllData();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        saveAllData();
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [scenes, layers, plays, commands, generatedHistory, selectedSceneId, activeTab, generatedStory]);

  // 主要数据变化时的自动保存（使用防抖）
  useEffect(() => {
    if (lastSaveTime) { // 避免初始化时的触发
      debouncedSave(scenes, 'scenes');
    }
  }, [scenes]);

  useEffect(() => {
    if (lastSaveTime) {
      debouncedSave(layers, 'layers');
    }
  }, [layers]);

  useEffect(() => {
    if (lastSaveTime) {
      debouncedSave(plays, 'plays');
    }
  }, [plays]);

  useEffect(() => {
    if (lastSaveTime) {
      debouncedSave(commands, 'commands');
    }
  }, [commands]);

  useEffect(() => {
    if (lastSaveTime) {
      debouncedSave(generatedHistory, 'history');
    }
  }, [generatedHistory]);

  // UI状态的即时保存
  useEffect(() => {
    if (lastSaveTime) {
      safeLocalStorage.set(STORAGE_KEYS.selectedSceneId, selectedSceneId);
    }
  }, [selectedSceneId]);

  useEffect(() => {
    if (lastSaveTime) {
      safeLocalStorage.set(STORAGE_KEYS.activeTab, activeTab);
    }
  }, [activeTab]);

  useEffect(() => {
    if (lastSaveTime) {
      safeLocalStorage.set(STORAGE_KEYS.generatedStory, generatedStory);
    }
  }, [generatedStory]);

  // 定期保存（每30秒）
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isSaving) {
        saveAllData();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [scenes, layers, plays, commands, generatedHistory, selectedSceneId, activeTab, generatedStory, isSaving]);

  // --- 工具函数 ---
  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast({ msg, type }), 3000);
  };

  const generateId = (prefix) => {
    return `${prefix}${Date.now().toString().slice(-6)}${Math.random().toString(36).slice(2, 8)}`;
  };

  // V1.3.16 新增: 编辑历史记录标题
  const handleEditHistoryTitle = (timestamp, newTitle) => {
    const trimmedTitle = newTitle.trim();
    if (!trimmedTitle) {
        setEditingHistoryId(null);
        showToast("标题不能为空，已取消修改", "error");
        return;
    }
    
    setGeneratedHistory(prev => prev.map(h => {
      if (h.timestamp === timestamp) {
        return { ...h, sceneName: trimmedTitle }; // 使用 sceneName 作为可编辑的标题
      }
      return h;
    }));
    
    setEditingHistoryId(null);
    setTempHistoryTitle('');
    showToast("故事标题已更新");
  };

  // V1.3 修复: 删除逻辑统一到此
  const openDeleteConfirmation = (id, type, name) => {
    setConfirmingDelete({ id, type, name });
  };

  const executeDelete = () => {
    if (!confirmingDelete) return;
    const { id, type } = confirmingDelete;

    if (type === 'scene') setScenes(prev => prev.filter(i => i.id !== id));
    if (type === 'layer') setLayers(prev => prev.filter(i => i.layer_id !== id));
    if (type === 'play') setPlays(prev => prev.filter(i => i.id !== id));
    if (type === 'command') setCommands(prev => prev.filter(i => i.id !== id));
    // 修复：清空所有历史记录的处理逻辑
    if (type === 'history' && id === 'ALL_HISTORY') setGeneratedHistory([]);
    if (type === 'history' && id !== 'ALL_HISTORY') setGeneratedHistory(prev => prev.filter(h => h.timestamp !== id));
    if (type === 'ALL') {
      setScenes(INITIAL_SCENES);
      setLayers(INITIAL_LAYERS);
      setPlays(INITIAL_PLAYS);
      setCommands(INITIAL_COMMANDS);
      setGeneratedHistory([]);
      // 清理所有本地存储
      clearAllData();
    }

    setConfirmingDelete(null);
    
    // 删除后立即保存
    setTimeout(() => {
      saveAllData();
    }, 100);
    
    showToast(type === 'ALL' ? "所有数据已重置并清理" : (type === 'history' && id === 'ALL_HISTORY' ? "所有历史记录已清空" : "删除成功"));
  };

  // V1.3 新增: 历史记录删除函数
  const handleDeleteHistory = (timestamp, name) => {
    openDeleteConfirmation(timestamp, 'history', `${name} 历史记录`);
  };

  // V1.3.2 新增: 复制故事文本到剪贴板 (修复权限错误，添加多层降级方案)
  const copyStoryToClipboard = (story, timestamp) => {
    try {
      // 生成文本内容
      const text = story.map(item => {
        if(item.type==='header') return `=== 场景: ${item.text.replace('场景：', '')} ===\n描述: ${item.desc}`;
        if(item.type==='play') return `[${item.layerName}] 玩法: ${item.title}\n描述: ${item.content}\n结果: ${item.result}`;
        if(item.type==='command') return `[指令] ${item.title} (${item.scope}): ${item.content}`;
        return '';
      }).join('\n\n');

      // 尝试使用 Clipboard API (现代方法)
      const copyWithClipboardAPI = async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopiedId(timestamp);
          setTimeout(() => setCopiedId(null), 2000);
          showToast("故事文本已复制到剪贴板");
        } catch (clipboardError) {
          // 降级方案: 创建临时文本框让用户手动复制
          copyWithFallback(text, timestamp);
        }
      };

      // 降级方案: 手动创建文本框选中内容
      const copyWithFallback = (textToCopy, ts) => {
        // 创建临时文本框
        const textArea = document.createElement('textarea');
        textArea.value = textToCopy;
        textArea.style.position = 'fixed';
        textArea.style.top = '-1000px';
        textArea.style.left = '-1000px';
        document.body.appendChild(textArea);

        // 选中并复制
        textArea.focus();
        textArea.select();
        textArea.setSelectionRange(0, textToCopy.length); // 兼容移动设备

        try {
          // 尝试 execCommand (旧版API，部分浏览器仍支持)
          document.execCommand('copy');
          setCopiedId(ts);
          setTimeout(() => setCopiedId(null), 2000);
          showToast("故事文本已复制到剪贴板 (降级模式)");
        } catch (execError) {
          // 完全降级: 提示用户手动复制
          showToast("复制失败，请手动复制文本", "error");
          // 创建弹窗显示文本
          const modal = document.createElement('div');
          modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.8);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-sizing: border-box;
          `;

          const content = document.createElement('div');
          content.style.cssText = `
            background: white;
            flex: 1;
            border-radius: 8px;
            padding: 20px;
            overflow: auto;
            margin: auto;
            max-width: 80%;
            max-height: 80%;
          `;

          const pre = document.createElement('pre');
          pre.style.cssText = `
            white-space: pre-wrap;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.5;
          `;
          pre.textContent = textToCopy;

          const closeBtn = document.createElement('button');
          closeBtn.textContent = '关闭';
          closeBtn.style.cssText = `
            margin-top: 16px;
            padding: 8px 16px;
            background: #6366f1;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
          `;
          closeBtn.onclick = () => document.body.removeChild(modal);

          content.appendChild(pre);
          content.appendChild(closeBtn);
          modal.appendChild(content);
          modal.style.display = 'flex'; // 确保显示
          document.body.appendChild(modal);

          // 自动选中文本
          // 确保 pre 是可编辑的才能 select
          pre.setAttribute('contenteditable', 'true');
          pre.focus();
          document.getSelection().selectAllChildren(pre);
          pre.removeAttribute('contenteditable');
        } finally {
          document.body.removeChild(textArea);
        }
      };

      // 执行复制逻辑
      copyWithClipboardAPI();

    } catch (err) {
      console.error("复制失败:", err);
      showToast("复制失败，请手动复制文本", "error");
    }
  };

  // V1.3.2 新增: 生成故事预览文本
  const getStoryPreview = (story) => {
    const previewLines = [];
    story.forEach(item => {
      if (item.type === 'header') previewLines.push(`场景: ${item.text.replace('场景：', '')}`);
      if (item.type === 'play') previewLines.push(`→ ${item.title}`);
      if (item.type === 'command') previewLines.push(`⚡ ${item.title}`);
    });
    // 只显示前5行
    return previewLines.slice(0, 5).join(' | ') + (previewLines.length > 5 ? '...' : '');
  };

  // V1.3.8 修改: 导出数据链接 (Data URI)
  const handleExportDataLink = () => {
    try {
        const fullData = { 
            scenes, 
            layers, 
            plays, 
            commands 
        };
        const dataJson = JSON.stringify(fullData);
        
        // 使用简单的 base64 编码以避免 URL 字符问题
        const base64Data = btoa(unescape(encodeURIComponent(dataJson)));
        
        // 构造 Data URI (公开可用的链接格式)
        const dataUri = `data:application/json;base64,${base64Data}`;

        // 尝试使用 Clipboard API 自动复制到剪贴板
        navigator.clipboard.writeText(dataUri)
            .then(() => {
                showToast("数据共享链接已复制到剪贴板");
            })
            .catch(() => {
                // 降级方案: 创建临时文本框让用户手动复制
                const textArea = document.createElement('textarea');
                textArea.value = dataUri;
                textArea.style.position = 'fixed';
                textArea.style.top = '-1000px';
                textArea.style.left = '-1000px';
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                textArea.setSelectionRange(0, dataUri.length);

                try {
                    document.execCommand('copy');
                    showToast("数据共享链接已复制到剪贴板 (降级模式)");
                } catch (execError) {
                    showToast("复制失败，请手动复制文本框中的链接", "error");
                } finally {
                    document.body.removeChild(textArea);
                }
            });
    } catch (err) {
        console.error("生成数据链接失败:", err);
        showToast("生成数据共享链接失败", "error");
    }
  };


  const openEdit = (item, type) => {
    setEditingItem(item);
    setTargetType(type);
    setModalMode("edit");
    setCommandScopeType(item.scope_type || 'GLOBAL');
    
    // V1.3.7 关键初始化: 初始化多选目标 ID 状态
    if (type === 'command') {
      const targetIds = item.fk_target_id ? item.fk_target_id.split(',').map(id => id.trim()).filter(Boolean) : [];
      setCommandTargetIds(targetIds);
    } else {
      setCommandTargetIds([]);
    }

    // V1.3.12 确保批量导入的数组状态在打开其他模式时被重置或不干扰
    setBatchCommandTargetIdsArray([]); 

    setModalOpen(true);
  };

  const openAdd = (type) => {
    setEditingItem(null);
    setTargetType(type);
    setModalMode("add");
    setCommandScopeType('GLOBAL');
    setCommandTargetIds([]); // Reset for add
    setBatchCommandTargetIdsArray([]); // V1.3.12 Reset
    setModalOpen(true);
  };

  const openBatch = (type) => {
    setBatchText("");
    setTargetType(type);
    setModalMode("batch");
    // [新增] 批量导入玩法时，默认选中第一个层级
    if (type === 'play' && layers.length > 0) {
        setBatchLayerId(layers[0].layer_id);
    }
    // [V1.3.9 新增] 批量导入指令时，重置作用域和目标ID
    if (type === 'command') {
        setBatchCommandScope('GLOBAL');
        setBatchCommandTargetIdsArray([]); // V1.3.12 New Reset
    }
    setModalOpen(true);
  };

  const openHistory = () => {
    setTargetType("history");
    setModalMode("history");
    // V1.3.16 新增: 打开历史记录时重置编辑状态
    setEditingHistoryId(null);
    setTempHistoryTitle('');
    setModalOpen(true);
  };

  // ------------------------------------------------------------------
  // [V1.3.10 关键修复] 导出生成故事为 TXT (修改为使用 Data URI 链接，以兼容 Android)
  const exportStoryToTxt = (story, storyTitle) => {
    const text = story.map(item => {
      if(item.type==='header') return `=== 场景: ${item.text.replace('场景：', '')} ===\n描述: ${item.desc}`;
      if(item.type==='play') return `[${item.layerName}] 玩法: ${item.title}\n描述: ${item.content}\n结果: ${item.result}`;
      if(item.type==='command') return `[指令] ${item.title} (${item.scope}): ${item.content}`;
      return '';
    }).join('\n\n');

    // 1. 对文本内容进行 URL 编码
    // 使用 encodeURIComponent 确保文本中的特殊字符（如换行、中文、标点）能安全地放入 URL 中
    const encodedText = encodeURIComponent(text); 
    
    // 2. 构造 Data URI
    // 格式: data:[<MIME-type>][;charset=<encoding>][;base64],<data>
    const dataUri = `data:text/plain;charset=utf-8,${encodedText}`;
    
    // 3. 创建下载链接并点击
    const a = document.createElement('a');
    a.href = dataUri; // <--- 使用 Data URI
    
    // 优化：支持中文文件名
    const fileName = `${storyTitle}_story_${new Date().toLocaleString().replace(/[/: ]/g, '-')}.txt`;
    a.download = fileName; // download 属性告诉浏览器使用此文件名
    
    // 4. 触发下载
    a.click();
    showToast("故事流程已导出为 TXT 文件");
  };
  // ------------------------------------------------------------------

  // ------------------------------------------------------------------
  // [V1.3.13 新增] 批量导出所有历史记录为 TXT
  const exportAllHistoryToTxt = () => {
    if (generatedHistory.length === 0) {
        showToast("没有历史记录可导出", "error");
        return;
    }

    let allText = "=== 剧情织造机 - 历史记录批量导出 ===\n";
    allText += `导出时间: ${new Date().toLocaleString()}\n\n`;

    generatedHistory.forEach((historyItem, index) => {
        // 1. 故事标题和元数据
        // V1.3.16 使用 sceneName 作为可编辑的标题
        allText += `\n==================== 故事 ${index + 1}: ${historyItem.sceneName} ====================\n`; 
        allText += `生成时间: ${new Date(historyItem.timestamp).toLocaleString()}\n\n`;

        // 2. 故事内容生成 (重用 exportStoryToTxt 的内部逻辑)
        const storyText = historyItem.story.map(item => {
            if (item.type === 'header') return `=== 场景: ${item.text.replace('场景：', '')} ===\n描述: ${item.desc}`;
            if (item.type === 'play') return `[${item.layerName}] 玩法: ${item.title}\n描述: ${item.content}\n结果: ${item.result}`;
            if (item.type === 'command') return `[指令] ${item.title} (${item.scope}): ${item.content}`;
            return '';
        }).join('\n\n');

        allText += storyText;
        allText += "\n";
    });

    // 3. 使用 Data URI 方式导出 (兼容 Android)
    const encodedText = encodeURIComponent(allText);
    const dataUri = `data:text/plain;charset=utf-8,${encodedText}`;

    const a = document.createElement('a');
    a.href = dataUri;
    const fileName = `all_story_history_${new Date().toLocaleString().replace(/[/: ]/g, '-')}.txt`;
    a.download = fileName;

    a.click();
    showToast(`成功批量导出 ${generatedHistory.length} 条历史记录为 TXT 文件`);
  };
  // ------------------------------------------------------------------


  // --- 智能解析与数据保存 ---
  const handleSave = (e) => {
    e.preventDefault();

    if (modalMode === 'batch') {
      handleBatchImport(targetType);
      return;
    }

    // 使用 FormData 获取非多选字段的值
    const formData = new FormData(e.target);
    const data = Object.fromEntries(formData.entries());

    // 数据清洗与格式化
    const parseTags = (tagString) => (tagString || "").split(/[,，]/).map(t => t.trim()).filter(Boolean);
    if (data.tags) data.tags = parseTags(data.tags);
    if (data.probability) data.probability = parseInt(data.probability);
    if (data.sequence) data.sequence = parseInt(data.sequence);

    // 根据类型保存
    if (targetType === 'scene') {
      const newItem = {
        id: editingItem ? editingItem.id : generateId('S'),
        name: data.name,
        description: data.description,
        tags: data.tags || []
      };
      setScenes(prev => editingItem ? prev.map(i => i.id === newItem.id ? newItem : i) : [...prev, newItem]);
    } else if (targetType === 'layer') {
      const newItem = {
        layer_id: editingItem ? editingItem.layer_id : generateId('L'),
        layer_name: data.layer_name,
        sequence: data.sequence || (layers.length + 1)
      };
      setLayers(prev => {
        const list = editingItem ? prev.map(i => i.layer_id === newItem.layer_id ? newItem : i) : [...prev, newItem];
        return list.sort((a, b) => a.sequence - b.sequence);
      });
    } else if (targetType === 'play') {
      const newItem = {
        id: editingItem ? editingItem.id : generateId('P'),
        name: data.name,
        description: data.description,
        trigger_condition: data.trigger_condition,
        result: data.result,
        fk_layer_id: data.fk_layer_id,
        tags: data.tags || []
      };
      setPlays(prev => editingItem ? prev.map(i => i.id === newItem.id ? newItem : i) : [...prev, newItem]);
    } else if (targetType === 'command') {
      
      // V1.3.7 关键修复：从状态中获取多选字段的值
      let fk_target_id_value = "";
      
      if (data.scope_type === 'SCENE' || data.scope_type === 'LAYER') {
          // V1.3.7 修复：从状态 commandTargetIds 获取已选中的 ID 数组，并转换为逗号分隔的字符串
          fk_target_id_value = commandTargetIds.join(',');
          
          if (!fk_target_id_value) {
               showToast(`请为 ${data.scope_type} 作用域选择至少一个目标`, "error");
               return; // 阻止保存
          }
      } else {
          // GLOBAL 作用域无需 target ID
          fk_target_id_value = "";
      }

      const newItem = {
        id: editingItem ? editingItem.id : generateId('C'),
        name: data.name,
        description: data.description,
        probability: data.probability,
        scope_type: data.scope_type,
        fk_target_id: fk_target_id_value // 使用状态中的值
      };
      setCommands(prev => editingItem ? prev.map(i => i.id === newItem.id ? newItem : i) : [...prev, newItem]);
    }

    setModalOpen(false);
    showToast(editingItem ? "更新成功" : "创建成功");
  };

  // --- 智能批量解析逻辑 (增强场景标签识别) ---
  const handleBatchImport = (type) => {
    if (!batchText.trim()) {
      showToast("请输入批量导入的内容", "error");
      return;
    }

    const lines = batchText.split('\n').filter(line => line.trim() !== "");
    let count = 0;
    const parseTags = (tagString) => (tagString || "").split(/[,，]/).map(t => t.trim()).filter(Boolean);
    
    // [V1.3.12 新增] 提取默认目标ID字符串
    let defaultTargetIdString = "";
    if (type === 'command' && (batchCommandScope === 'SCENE' || batchCommandScope === 'LAYER')) {
        defaultTargetIdString = batchCommandTargetIdsArray.join(',');
    }


    try {
      const newItems = lines.map((line, index) => {
        let content = line.trim().replace(/^[\d\-\.\、\)\(]+\s*/, '');
        let parts;
        if (content.includes('|') || content.includes('｜')) {
          parts = content.split(/[|｜]/).map(p => p.trim());
        } else if (content.includes(':') || content.includes('：')) {
          parts = content.split(/[:：]/).map(p => p.trim());
        } else {
          parts = [content];
        }

        if (type === 'scene') {
          // 格式期望: 名称 | 描述 | 标签1,标签2
          const name = parts[0];
          if (!name) return null;

          // V1.3 新增: 增强标签识别
          let tags = parseTags(parts[2]);
          if (tags.length === 0 && parts[1]) {
            const tagMatch = parts[1].match(/(\[([^\]]+)\]|\(([^\)]+)\))$/);
            if (tagMatch) {
                tags = parseTags(tagMatch[2] || tagMatch[3]);
                parts[1] = parts[1].replace(tagMatch[0], '').trim();
            }
          }

          return {
            id: generateId('S'),
            name: name,
            description: parts[1] || `${name} (批量导入)`,
            tags: tags
          };
        }
        else if (type === 'play') {
          // 格式期望: 名称 | 描述 | 结果 | 层级ID | 标签
          const name = parts[0];
          if (!name) return null;

          // [修改] 优先使用用户在模态框中选择的 batchLayerId
          let layerId = batchLayerId || parts[3] || (layers.length > 0 ? layers[0].layer_id : "");

          return {
            id: generateId('P'),
            name: name,
            description: parts[1] || "暂无描述",
            result: parts[2] || "未知结果",
            fk_layer_id: layerId, // <-- 使用 batchLayerId
            trigger_condition: "自动",
            tags: parseTags(parts[4])
          };
        }
        else if (type === 'command') {
          // 格式期望: 名称 | 描述 | 概率 | 作用域 (GLOBAL/SCENE/LAYER) | 目标ID (S001,S002 或 L1_SETUP,L2_CORE)
          const name = parts[0];
          if (!name) return null;

          // [V1.3.9 修改] 如果文本行中未指定作用域 (parts[3]为空)，则使用模态框中选择的 batchCommandScope
          let scope = parts[3] ? parts[3].toUpperCase() : batchCommandScope;
          if (!['GLOBAL', 'SCENE', 'LAYER'].includes(scope)) scope = 'GLOBAL';
          
          // 批量导入时目标 ID 直接使用输入的字符串
          let targetId = parts[4] || "";

          // [V1.3.12 关键修改] 如果作用域为 SCENE/LAYER 且文本行未指定目标ID，则使用默认的选择列表值
          if ((scope === 'SCENE' || scope === 'LAYER') && !targetId) {
              targetId = defaultTargetIdString;
          }

          return {
            id: generateId('C'),
            name: name,
            description: parts[1] || "系统指令",
            probability: parseInt(parts[2]) || 20,
            scope_type: scope, // 使用更新后的 scope
            fk_target_id: targetId // 使用更新后的 targetId
          };
        }
        return null;
      }).filter(Boolean);

      if (newItems.length === 0) {
        showToast("未解析到有效数据，请检查格式", "error");
        return;
      }

      if (type === 'scene') setScenes(prev => [...prev, ...newItems]);
      else if (type === 'play') setPlays(prev => [...prev, ...newItems]);
      else if (type === 'command') setCommands(prev => [...prev, ...newItems]);

      count = newItems.length;
      showToast(`智能识别并导入 ${count} 条数据`);
      setModalOpen(false);
    } catch (e) {
      console.error("批量导入解析错误:", e);
      showToast(`解析失败: ${e.message}`, "error");
    }
  };

  // --- 随机生成器逻辑 (略) ---
  const handleGenerateStory = () => {
    if (!selectedSceneId) {
      showToast("请先选择一个起始场景！", "error");
      return;
    }

    const scene = scenes.find(s => s.id === selectedSceneId);
    if (!scene) return;

    let storyFlow = [];

    // 1. 添加场景头
    storyFlow.push({ type: 'header', text: `场景：${scene.name}`, desc: scene.description });

    // 2. 遍历层级
    const sortedLayers = [...layers].sort((a, b) => a.sequence - b.sequence);

    sortedLayers.forEach(layer => {
      // A. 抽取玩法 (Play)
      const layerPlays = plays.filter(p => p.fk_layer_id === layer.layer_id);

      if (layerPlays.length > 0) {
        const scoredPlays = layerPlays.map(p => {
          const matchCount = p.tags.filter(t => scene.tags.includes(t)).length;
          return { ...p, score: matchCount };
        });

        const maxScore = Math.max(...scoredPlays.map(p => p.score));
        const matchedPlays = maxScore > 0
          ? scoredPlays.filter(p => p.score === maxScore)
          : layerPlays;

        const selectedPlay = matchedPlays[Math.floor(Math.random() * matchedPlays.length)];

        storyFlow.push({
          type: 'play',
          layerName: layer.layer_name,
          title: selectedPlay.name,
          content: selectedPlay.description,
          result: selectedPlay.result
        });
      }

      // B. 抽取指令 (Command)
      const possibleCommands = commands.filter(c => {
        if (c.scope_type === 'GLOBAL') return true;
        
        // V1.3.7 统一处理 SCENE 和 LAYER 的多目标 ID 检查
        const targetIds = c.fk_target_id ? c.fk_target_id.split(',').map(id => id.trim()).filter(Boolean) : [];

        if (c.scope_type === 'SCENE') {
            // 检查当前场景ID是否在目标ID列表中
            if (targetIds.includes(scene.id)) return true;
        }

        if (c.scope_type === 'LAYER') {
            // 检查当前层级ID是否在目标ID列表中 (支持多选)
            if (targetIds.includes(layer.layer_id)) return true;
        }
        return false;
      });

      possibleCommands.forEach(cmd => {
        const roll = Math.random() * 100;
        if (roll <= cmd.probability) {
          storyFlow.push({
            type: 'command',
            title: cmd.name,
            content: cmd.description,
            scope: cmd.scope_type
          });
        }
      });
    });

    setGeneratedStory(storyFlow);

    // V1.3 新增: 存储到历史记录
    setGeneratedHistory(prev => [{
      timestamp: Date.now(),
      sceneName: scene.name, // 默认使用场景名称作为历史记录标题
      story: storyFlow,
    }, ...prev]);

    showToast("故事流程已生成并保存到历史记录");
  };

  // 新增：开启剧情走向模式
  const startInteractiveMode = () => {
    if (!selectedSceneId) {
      showToast("请先选择一个起始场景！", "error");
      return;
    }

    const scene = scenes.find(s => s.id === selectedSceneId);
    if (!scene) return;

    setCurrentScene(scene);
    setCurrentLayerIndex(0);
    setInteractiveStory([{
      type: 'header',
      text: `场景：${scene.name}`,
      desc: scene.description
    }]);
    setSelectedChoices([]);
    setSelectedCommands([]);
    setInteractiveMode(true);
    showToast("进入剧情走向模式");
  };

  // 新增：退出剧情走向模式
  const exitInteractiveMode = () => {
    if (confirm("确定要退出剧情走向模式吗？当前进度将不会保存到历史记录。")) {
      setInteractiveMode(false);
      setCurrentLayerIndex(0);
      setInteractiveStory([]);
      setSelectedChoices([]);
      setSelectedCommands([]);
      setCurrentScene(null);
      // 保存退出状态
      safeLocalStorage.set(STORAGE_KEYS.interactiveMode, false);
      showToast("已退出剧情走向模式");
    }
  };

  // 新增：获取当前层级的候选选项
  const getCandidatesForCurrentLayer = () => {
    if (!currentScene || currentLayerIndex >= layers.length) return { plays: [], commands: [] };
    
    const sortedLayers = [...layers].sort((a, b) => a.sequence - b.sequence);
    const currentLayer = sortedLayers[currentLayerIndex];
    
    // 获取玩法候选（基于标签匹配）
    const layerPlays = plays.filter(p => p.fk_layer_id === currentLayer.layer_id);
    const scoredPlays = layerPlays.map(p => {
      const matchCount = p.tags.filter(t => currentScene.tags.includes(t)).length;
      return { ...p, score: matchCount };
    });
    
    // 选择最匹配的3-4个玩法
    const maxScore = Math.max(...scoredPlays.map(p => p.score));
    const matchedPlays = maxScore > 0
      ? scoredPlays.filter(p => p.score === maxScore)
      : layerPlays;
    
    const selectedPlays = matchedPlays
      .sort(() => Math.random() - 0.5)
      .slice(0, Math.min(4, matchedPlays.length));

    // 获取指令候选（基于概率）
    const possibleCommands = commands.filter(c => {
      if (c.scope_type === 'GLOBAL') return true;
      
      const targetIds = c.fk_target_id ? c.fk_target_id.split(',').map(id => id.trim()).filter(Boolean) : [];
      
      if (c.scope_type === 'SCENE') {
        return targetIds.includes(currentScene.id);
      }
      if (c.scope_type === 'LAYER') {
        return targetIds.includes(currentLayer.layer_id);
      }
      return false;
    });

    const triggeredCommands = possibleCommands.filter(cmd => {
      const roll = Math.random() * 100;
      return roll <= cmd.probability;
    });

    return {
      plays: selectedPlays,
      commands: triggeredCommands
    };
  };

  // 新增：处理用户选择
  const handleInteractiveChoice = () => {
    if (selectedChoices.length === 0 && selectedCommands.length === 0) {
      showToast("请至少选择一个选项", "error");
      return;
    }

    const sortedLayers = [...layers].sort((a, b) => a.sequence - b.sequence);
    const currentLayer = sortedLayers[currentLayerIndex];
    
    // 添加选择结果到故事
    const newStoryItems = [];
    
    // 添加玩法结果
    selectedChoices.forEach(playId => {
      const play = plays.find(p => p.id === playId);
      if (play) {
        newStoryItems.push({
          type: 'play',
          layerName: currentLayer.layer_name,
          title: play.name,
          content: play.description,
          result: play.result
        });
      }
    });

    // 添加指令结果
    selectedCommands.forEach(cmdId => {
      const cmd = commands.find(c => c.id === cmdId);
      if (cmd) {
        newStoryItems.push({
          type: 'command',
          title: cmd.name,
          content: cmd.description,
          scope: cmd.scope_type
        });
      }
    });

    setInteractiveStory(prev => [...prev, ...newStoryItems]);

    // 清空选择
    setSelectedChoices([]);
    setSelectedCommands([]);

    // 移动到下一层级或结束
    if (currentLayerIndex < sortedLayers.length - 1) {
      setCurrentLayerIndex(prev => prev + 1);
      showToast(`进入第 ${currentLayerIndex + 2} 幕`);
    } else {
      // 故事结束，保存到历史记录
      setGeneratedHistory(prev => [{
        timestamp: Date.now(),
        sceneName: `${currentScene.name} (剧情走向)`,
        story: interactiveStory,
      }, ...prev]);
      showToast("剧情走向完成，已保存到历史记录");
      setInteractiveMode(false);
    }
  };

  // --- 渲染模态框内容 (略) ---
  const renderModalContent = () => {
    const item = editingItem || {};
    const title = modalMode === 'add' ? `新增 ${targetType === 'scene' ? '场景' : targetType === 'layer' ? '层级' : targetType === 'play' ? '玩法' : '指令'}` : (modalMode === 'edit' ? `编辑 ${item.name || item.layer_name}` : (modalMode === 'batch' ? `批量导入 ${targetType === 'scene' ? '场景' : targetType === 'play' ? '玩法' : '指令'}` : '历史记录'));

    if (modalMode === 'history') {
      return { title: '历史生成记录', content: renderHistoryModal() };
    }

    if (modalMode === 'batch') {
      const examples = {
        scene: "名称 | 描述 | 标签1,标签2\n废弃仓库 | 阴暗潮湿，地板上布满铁锈。 [室内, 恐怖] |",
        play: "名称 | 描述 | 结果 | 层级ID (如L2_CORE) | 标签\n修好电闸 | 找到电闸并成功修复。 | 恢复照明 | L1_SETUP | 电力, 辅助",
        // V1.3.7 示例：指令的目标ID也支持逗号分隔
        command: "名称 | 描述 | 概率 | 作用域 (GLOBAL/SCENE/LAYER) | 目标ID (S001,S002 或 L1_SETUP,L2_CORE)\n怪物嘶吼 | 远处传来令人毛骨悚然的吼叫。 | 10 | SCENE | S001,S002"
      };

      return {
        title: title,
        content: (
          <form onSubmit={handleSave}>
            <p className="text-sm text-slate-500 mb-3">
              请按行输入数据，字段间使用 **`|`** 或 **`:`** 分隔。
              <span className="text-indigo-600 font-medium ml-1">场景导入支持智能识别描述末尾的 `[]` 或 `()` 内的标签。</span>
            </p>
            <div className="text-xs text-slate-400 bg-slate-50 p-3 rounded-lg overflow-x-auto whitespace-pre-wrap font-mono mb-4">
              <span className="font-semibold text-slate-700 block mb-1">格式示例 ({targetType}):</span>
              {examples[targetType]}
            </div>
            
            {/* [新增] 批量导入玩法目标层级 */}
            {targetType === 'play' && layers.length > 0 && (
                <div className="mb-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">批量导入的目标层级 (统一设置，文本行可覆盖)</label>
                    <select 
                        value={batchLayerId} 
                        onChange={(e) => setBatchLayerId(e.target.value)} 
                        className="w-full border border-slate-300 rounded-lg p-2 bg-white" 
                        required
                    >
                        {layers.map(l => (
                            <option key={l.layer_id} value={l.layer_id}>{l.sequence}. {l.layer_name} ({l.layer_id})</option>
                        ))}
                    </select>
                </div>
            )}
            
            {/* [V1.3.9 新增] 批量导入指令默认作用域选择 */}
            {targetType === 'command' && (
                <div className="mb-4">
                    <label className="block text-sm font-medium text-slate-700 mb-1">批量导入的默认作用域 (统一设置，文本行可覆盖)</label>
                    <select 
                        value={batchCommandScope} 
                        onChange={(e) => {
                            setBatchCommandScope(e.target.value);
                            // 作用域改变时清空已选的目标
                            setBatchCommandTargetIdsArray([]); 
                        }} 
                        className="w-full border border-slate-300 rounded-lg p-2 bg-white" 
                        required
                    >
                        <option value="GLOBAL">GLOBAL (全局生效)</option>
                        <option value="SCENE">SCENE (特定场景)</option>
                        <option value="LAYER">LAYER (特定层级)</option>
                    </select>
                    <p className="text-xs text-slate-500 mt-1">如果文本行中未指定作用域，将使用此默认值。</p>
                </div>
            )}
            
            {/* [V1.3.12 关键修改] 批量导入指令默认目标ID - 使用选择列表 */}
            {targetType === 'command' && (batchCommandScope === 'SCENE' || batchCommandScope === 'LAYER') && (
                <div className="mb-4 bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <label className="block text-sm font-medium text-slate-700 mb-1">
                        默认目标ID (可多选)
                    </label>
                    {batchCommandScope === 'SCENE' && (
                        <CheckboxList
                            name="batch_scene_target"
                            options={scenes.map(s => ({ id: s.id, name: `${s.name} (${s.id})` }))}
                            selectedValues={batchCommandTargetIdsArray}
                            onChange={setBatchCommandTargetIdsArray}
                        />
                    )}
                    {batchCommandScope === 'LAYER' && (
                        <CheckboxList
                            name="batch_layer_target"
                            options={layers.map(l => ({ id: l.layer_id, name: `${l.sequence}. ${l.layer_name} (${l.layer_id})` }))}
                            selectedValues={batchCommandTargetIdsArray}
                            onChange={setBatchCommandTargetIdsArray}
                        />
                    )}
                    <p className="text-xs text-slate-500 mt-2">
                        所选 ID 将作为默认值应用于作用域为 **{batchCommandScope === 'SCENE' ? '特定场景' : '特定层级'}** 且文本行中目标ID为空的指令。
                    </p>
                </div>
            )}


            <textarea
              name="batchText"
              rows="10"
              placeholder="每行一条数据..."
              value={batchText}
              onChange={(e) => setBatchText(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-3 text-sm focus:ring-indigo-500 focus:border-indigo-500"
              required
            ></textarea>
            <div className="mt-4 flex justify-end">
              <Button type="submit" size="md"><Upload size={16} className="mr-2"/> 确认导入</Button>
            </div>
          </form>
        )
      };
    }

    // Add/Edit Form (略)
    return {
      title: title,
      content: (
        <form onSubmit={handleSave}>
          {targetType === 'scene' && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-slate-700">名称</label>
              <input type="text" name="name" defaultValue={item.name} className="w-full border border-slate-300 rounded-lg p-2" required />

              <label className="block text-sm font-medium text-slate-700">描述</label>
              <textarea name="description" defaultValue={item.description} rows="3" className="w-full border border-slate-300 rounded-lg p-2"></textarea>

              <label className="block text-sm font-medium text-slate-700">标签 (逗号或顿号分隔)</label>
              <input type="text" name="tags" defaultValue={(item.tags || []).join(', ')} placeholder="例如: 室内, 恐怖, 解谜" className="w-full border border-slate-300 rounded-lg p-2" />
            </div>
          )}

          {targetType === 'layer' && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-slate-700">层级名称</label>
              <input type="text" name="layer_name" defaultValue={item.layer_name} className="w-full border border-slate-300 rounded-lg p-2" required />

              <label className="block text-sm font-medium text-slate-700">执行顺序</label>
              <input type="number" name="sequence" defaultValue={item.sequence} className="w-full border border-slate-300 rounded-lg p-2" min="1" required />
            </div>
          )}

          {targetType === 'play' && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-slate-700">玩法名称</label>
              <input type="text" name="name" defaultValue={item.name} className="w-full border border-slate-300 rounded-lg p-2" required />

              <label className="block text-sm font-medium text-slate-700">描述 (玩家行为)</label>
              <textarea name="description" defaultValue={item.description} rows="3" className="w-full border border-slate-300 rounded-lg p-2"></textarea>

              <label className="block text-sm font-medium text-slate-700">预期结果</label>
              <input type="text" name="result" defaultValue={item.result} className="w-full border border-slate-300 rounded-lg p-2" required />

              <label className="block text-sm font-medium text-slate-700">触发条件 (可选)</label>
              <input type="text" name="trigger_condition" defaultValue={item.trigger_condition} className="w-full border border-slate-300 rounded-lg p-2" />

              <label className="block text-sm font-medium text-slate-700">所属层级</label>
              <select name="fk_layer_id" defaultValue={item.fk_layer_id || (layers[0]?.layer_id)} className="w-full border border-slate-300 rounded-lg p-2" required>
                {layers.map(l => (
                  <option key={l.layer_id} value={l.layer_id}>{l.sequence}. {l.layer_name} ({l.layer_id})</option>
                ))}
              </select>

              <label className="block text-sm font-medium text-slate-700">标签 (逗号或顿号分隔)</label>
              <input type="text" name="tags" defaultValue={(item.tags || []).join(', ')} placeholder="例如: 战斗, 室内, 生存" className="w-full border border-slate-300 rounded-lg p-2" />
            </div>
          )}

          {targetType === 'command' && (
            <div className="space-y-3">
              <label className="block text-sm font-medium text-slate-700">指令名称</label>
              <input type="text" name="name" defaultValue={item.name} className="w-full border border-slate-300 rounded-lg p-2" required />

              <label className="block text-sm font-medium text-slate-700">描述/效果</label>
              <textarea name="description" defaultValue={item.description} rows="3" className="w-full border border-slate-300 rounded-lg p-2"></textarea>

              <label className="block text-sm font-medium text-slate-700">触发概率 (%)</label>
              <input type="number" name="probability" defaultValue={item.probability || 20} className="w-full border border-slate-300 rounded-lg p-2" min="1" max="100" required />

              <label className="block text-sm font-medium text-slate-700">作用域</label>
              <select
                name="scope_type"
                defaultValue={item.scope_type || 'GLOBAL'}
                className="w-full border border-slate-300 rounded-lg p-2"
                // V1.3.7 优化：作用域变化时，重置目标 ID 状态
                onChange={(e) => {
                  setCommandScopeType(e.target.value);
                  setCommandTargetIds([]);
                }}
                required
              >
                <option value="GLOBAL">GLOBAL (全局)</option>
                <option value="SCENE">SCENE (特定场景)</option>
                <option value="LAYER">LAYER (特定层级)</option>
              </select>

              {/* V1.3.7 关键修复: 动态目标ID输入 (改为多选框列表，支持 SCENE 和 LAYER 多选) */}
              {commandScopeType !== 'GLOBAL' && (
                <>
                  <label className="block text-sm font-medium text-slate-700">目标 ID / 名称</label>
                  {commandScopeType === 'SCENE' && (
                    <CheckboxList
                      name="fk_target_id"
                      options={scenes.map(s => ({ id: s.id, name: `${s.name} (${s.id})` }))}
                      selectedValues={commandTargetIds}
                      onChange={setCommandTargetIds}
                      required
                    />
                  )}
                  {commandScopeType === 'LAYER' && (
                    <CheckboxList 
                      name="fk_target_id"
                      // LAYER 现在也支持多选
                      options={layers.map(l => ({ id: l.layer_id, name: `${l.sequence}. ${l.layer_name} (${l.layer_id})` }))}
                      selectedValues={commandTargetIds}
                      onChange={setCommandTargetIds}
                      required
                    />
                  )}
                </>
              )}
            </div>
          )}

          <div className="mt-6 flex justify-end space-x-3">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>取消</Button>
            <Button type="submit">
              <Save size={16} className="mr-2"/> 保存
            </Button>
          </div>
        </form>
      )
    };
  };

  // --- 渲染历史记录模态框 (V1.3.16 重点修改此函数) ---
  const renderHistoryModal = () => (
    <div className="space-y-4">
      {/* V1.3.13 优化：顶部布局，支持批量导出 */}
      <div className="flex flex-col sm:flex-row justify-between items-center space-y-2 sm:space-y-0">
        <div className="text-sm text-slate-500">
          总共保存了 {generatedHistory.length} 条历史故事记录
        </div>
        {generatedHistory.length > 0 && (
          <div className="flex space-x-2">
            <Button
                variant="secondary"
                size="sm"
                onClick={exportAllHistoryToTxt} // <-- 批量导出
            >
                <Download size={14} className="mr-1"/> 批量导出 TXT
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => openDeleteConfirmation('ALL_HISTORY', 'history', '所有历史记录')}
            >
              <Trash2 size={14} className="mr-1"/> 清空历史
            </Button>
          </div>
        )}
      </div>

      {generatedHistory.length === 0 ? (
        <div className="text-center py-8 text-slate-400">
          <History size={48} className="mx-auto mb-2 opacity-20" />
          <p>暂无历史生成记录</p>
          <p className="text-xs mt-1">生成故事后会自动保存到这里</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-2">
          {generatedHistory.map((historyItem) => (
            <Card key={historyItem.timestamp} className="p-4 border-l-4 border-l-indigo-300 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-2">
                
                {/* V1.3.16 标题和编辑区域 */}
                <div className="flex flex-col items-start w-full pr-4">
                    <div className="flex items-center space-x-2">
                        {editingHistoryId === historyItem.timestamp ? (
                            <input
                                type="text"
                                value={tempHistoryTitle}
                                onChange={(e) => setTempHistoryTitle(e.target.value)}
                                onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                        e.preventDefault();
                                        handleEditHistoryTitle(historyItem.timestamp, tempHistoryTitle);
                                    }
                                }}
                                onBlur={() => handleEditHistoryTitle(historyItem.timestamp, tempHistoryTitle)}
                                className="text-base font-bold text-slate-800 border border-indigo-400 rounded px-1 py-0.5 focus:outline-none w-full"
                                autoFocus
                            />
                        ) : (
                            <h4
                                className="font-bold text-slate-800 flex items-center cursor-pointer hover:text-indigo-600 transition-colors"
                                onClick={() => {
                                    setEditingHistoryId(historyItem.timestamp);
                                    setTempHistoryTitle(historyItem.sceneName);
                                }}
                                title="点击编辑故事简称"
                            >
                                {historyItem.sceneName}
                                <Edit3 size={14} className="ml-2 text-indigo-400 opacity-70 hover:opacity-100 flex-shrink-0" />
                            </h4>
                        )}
                        <Badge size="sm" color="blue" className="flex-shrink-0">
                            {historyItem.story.length} 步
                        </Badge>
                    </div>
                    {/* V1.3.2 新增: 生成时间 */}
                    <p className="text-xs text-slate-500 mt-1">
                        生成时间: {new Date(historyItem.timestamp).toLocaleString()}
                    </p>
                </div>

                {/* 按钮组 */}
                <div className="flex space-x-1 flex-shrink-0">
                  {/* V1.3.2 新增: 复制按钮 */}
                  <Button
                    size="icon"
                    variant="secondary"
                    title="复制文本到剪贴板"
                    onClick={() => copyStoryToClipboard(historyItem.story, historyItem.timestamp)}
                    className={copiedId === historyItem.timestamp ? 'text-green-600 bg-green-50 border-green-100' : ''}
                  >
                    {copiedId === historyItem.timestamp ? <Check size={16}/> : <Copy size={16}/>}
                  </Button>

                  <Button
                    size="icon"
                    variant="secondary"
                    title="导出为 TXT"
                    onClick={() => exportStoryToTxt(historyItem.story, historyItem.sceneName)}
                  >
                    <Download size={16}/>
                  </Button>

                  <Button
                    size="icon"
                    variant="lightDanger"
                    title="删除此记录"
                    onClick={() => handleDeleteHistory(historyItem.timestamp, historyItem.sceneName)}
                  >
                    <Trash2 size={16}/>
                  </Button>
                </div>
              </div>

              {/* V1.3.2 新增: 内容预览 */}
              <div className="text-xs text-slate-600 bg-slate-50 p-2 rounded-md font-mono mt-3">
                {getStoryPreview(historyItem.story)}
              </div>

              <div className="mt-3 flex justify-end">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setGeneratedStory(historyItem.story);
                    setModalOpen(false);
                    setActiveTab('generator');
                    showToast("历史故事已加载");
                  }}
                >
                  <History size={14} className="mr-1"/> 加载到主面板
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );

  // --- 渲染删除确认模态框 (V1.3.19 修复层级) ---
  const renderConfirmModal = () => {
    if (!confirmingDelete) return null;

    // 处理清空所有历史记录的确认
    const isClearHistory = confirmingDelete.type === 'history' && confirmingDelete.id === 'ALL_HISTORY';
    const title = confirmingDelete.type === 'ALL' ? "重置所有数据" : (isClearHistory ? "清空历史记录" : "确认删除");
    const message = confirmingDelete.type === 'ALL'
      ? "你确定要清空所有数据（场景、层级、玩法、指令和历史记录）吗？此操作不可恢复。"
      : (isClearHistory
        ? "你确定要删除所有历史生成记录吗？此操作不可恢复。"
        : `你确定要删除 **${confirmingDelete.name}** 吗？此操作不可恢复。`);

    return (
      <Modal 
        isOpen={!!confirmingDelete} 
        onClose={() => setConfirmingDelete(null)} 
        title={title}
        zIndex={52} // V1.3.19 关键修改：将层级提升到 52，内容层级为 53，确保高于主模态框的 50/51
      >
        <div className="flex items-center space-x-3">
          <AlertTriangle size={24} className="text-red-500 flex-shrink-0" />
          <p className="text-slate-700">
            {message}
          </p>
        </div>
        <div className="flex justify-end space-x-3 mt-4">
          <Button variant="secondary" onClick={() => setConfirmingDelete(null)}>取消</Button>
          <Button variant="danger" onClick={executeDelete}>
            <Trash2 size={16} className="mr-2"/> {confirmingDelete.type === 'ALL' ? "清空所有" : (isClearHistory ? "清空记录" : "确认删除")}
          </Button>
        </div>
      </Modal>
    );
  };

  // --- 渲染列表视图 (略) ---
  const renderSceneList = () => (
    <div className="space-y-4 pb-24">
      <div className="flex justify-between items-center mb-4 px-1">
        <h2 className="text-xl font-bold text-slate-800 flex items-center"><MapPin size={22} className="mr-2"/> 场景管理</h2>
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm" onClick={() => openBatch('scene')}><ListPlus size={16} className="mr-1"/> 批量</Button>
          <Button size="sm" onClick={() => openAdd('scene')}><Plus size={16} className="mr-1"/> 新增</Button>
        </div>
      </div>
      {scenes.map(scene => (
        <Card key={scene.id} className="relative group">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-bold text-slate-800">{scene.name}</h3>
              <p className="text-sm text-slate-500 mt-1 line-clamp-2">{scene.description}</p>
              <div className="mt-2 flex flex-wrap gap-1">
                {scene.tags.map(t => <Badge key={t} color="blue">{t}</Badge>)}
              </div>
            </div>
            <div className="flex space-x-2 flex-shrink-0">
              <button onClick={() => openEdit(scene, 'scene')} className="p-2 text-slate-400 hover:text-indigo-600"><Edit3 size={18}/></button>
              <button onClick={() => openDeleteConfirmation(scene.id, 'scene', scene.name)} className="p-2 text-slate-400 hover:text-red-600"><Trash2 size={18}/></button>
            </div>
          </div>
          <div className="absolute top-2 right-2 opacity-10 text-[10px]">{scene.id}</div>
        </Card>
      ))}
    </div>
  );

  const renderLayerList = () => (
    <div className="space-y-4 pb-24">
      <div className="flex justify-between items-center mb-4 px-1">
        <h2 className="text-xl font-bold text-slate-800 flex items-center"><Layers size={22} className="mr-2"/> 玩法层级</h2>
        <Button size="sm" onClick={() => openAdd('layer')}><Plus size={16} className="mr-1"/> 新增层级</Button>
      </div>
      {[...layers].sort((a,b) => a.sequence - b.sequence).map((layer) => (
        <Card key={layer.layer_id} className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-500">
              {layer.sequence}
            </div>
            <div>
              <h3 className="font-bold text-slate-800">{layer.layer_name}</h3>
              <span className="text-xs text-slate-400 font-mono">{layer.layer_id}</span>
            </div>
          </div>
          <div className="flex space-x-1 flex-shrink-0">
            <button onClick={() => openEdit(layer, 'layer')} className="p-2 text-slate-400 hover:text-indigo-600"><Edit3 size={18}/></button>
            <button onClick={() => openDeleteConfirmation(layer.layer_id, 'layer', layer.layer_name)} className="p-2 text-slate-400 hover:text-red-600"><Trash2 size={18}/></button>
          </div>
        </Card>
      ))}
    </div>
  );

  const renderPlayList = () => (
    <div className="space-y-4 pb-24">
      <div className="flex justify-between items-center mb-4 px-1">
        <h2 className="text-xl font-bold text-slate-800 flex items-center"><BookOpen size={22} className="mr-2"/> 玩法库</h2>
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm" onClick={() => openBatch('play')}><ListPlus size={16} className="mr-1"/> 批量</Button>
          <Button size="sm" onClick={() => openAdd('play')}><Plus size={16} className="mr-1"/> 新增</Button>
        </div>
      </div>
      {[...layers].sort((a, b) => a.sequence - b.sequence).map(layer => {
        const layerPlays = plays.filter(p => p.fk_layer_id === layer.layer_id);
        if (layerPlays.length === 0) return null;
        return (
          <div key={layer.layer_id} className="mb-6">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2 pl-1">{layer.layer_name}</h3>
            {layerPlays.map(play => (
              <Card key={play.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-slate-800">{play.name}</h4>
                    <p className="text-sm text-slate-600 mt-1">{play.description}</p>
                    <div className="mt-2 text-xs text-slate-500">
                      <span className="font-semibold">结果:</span> {play.result}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {play.tags.map(t => <Badge key={t} color="purple">{t}</Badge>)}
                    </div>
                  </div>
                  <div className="flex flex-col space-y-1 flex-shrink-0">
                    <button onClick={() => openEdit(play, 'play')} className="p-2 text-slate-400 hover:text-indigo-600"><Edit3 size={16}/></button>
                    <button onClick={() => openDeleteConfirmation(play.id, 'play', play.name)} className="p-2 text-slate-400 hover:text-red-600"><Trash2 size={16}/></button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )
      })}
    </div>
  );

  const renderCommandList = () => (
    <div className="space-y-4 pb-24">
      <div className="flex justify-between items-center mb-4 px-1">
        <h2 className="text-xl font-bold text-slate-800 flex items-center"><Zap size={22} className="mr-2"/> 场外指令</h2>
        <div className="flex space-x-2">
          <Button variant="secondary" size="sm" onClick={() => openBatch('command')}><ListPlus size={16} className="mr-1"/> 批量</Button>
          <Button size="sm" onClick={() => openAdd('command')}><Plus size={16} className="mr-1"/> 新增</Button>
        </div>
      </div>
      {commands.map(cmd => {
        let targetName = "N/A";
        const targetIds = cmd.fk_target_id ? cmd.fk_target_id.split(',').map(id => id.trim()).filter(Boolean) : [];

        if (cmd.scope_type === 'SCENE' && targetIds.length > 0) {
            // 场景多选
            const targetNames = targetIds.map(id => scenes.find(s => s.id === id)?.name || id);
            targetName = targetNames.join(', ');
        } else if (cmd.scope_type === 'LAYER' && targetIds.length > 0) {
          // V1.3.7 修复：层级多选
          const targetNames = targetIds.map(id => layers.find(l => l.layer_id === id)?.layer_name || id);
          targetName = targetNames.join(', ');
        }

        return (
          <Card key={cmd.id} className="border-l-4 border-l-amber-400">
            <div className="flex justify-between items-start">
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className="font-bold text-slate-800">{cmd.name}</h3>
                  <Badge color="orange">{cmd.probability}%</Badge>
                  <Badge color="slate">{cmd.scope_type}</Badge>
                </div>
                <p className="text-sm text-slate-600 mt-1">{cmd.description}</p>
                {cmd.scope_type !== 'GLOBAL' && (
                  <div className="mt-1 text-xs text-slate-400 font-mono">
                    目标: {targetName}
                  </div>
                )}
              </div>
              <div className="flex space-x-1 flex-shrink-0">
                 <button onClick={() => openEdit(cmd, 'command')} className="p-2 text-slate-400 hover:text-indigo-600"><Edit3 size={18}/></button>
                 <button onClick={() => openDeleteConfirmation(cmd.id, 'command', cmd.name)} className="p-2 text-slate-400 hover:text-red-600"><Trash2 size={18}/></button>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );

  const renderGenerator = () => {
    if (interactiveMode) {
      return renderInteractiveMode();
    }

    return (
      <div className="space-y-6 pb-24">
        <div className="bg-indigo-600 p-6 rounded-2xl text-white shadow-lg shadow-indigo-200">
          <h2 className="text-2xl font-bold mb-4 flex items-center"><Play className="mr-2"/> 开始生成</h2>
          <div className="space-y-3">
            <label className="text-sm text-indigo-100 font-medium">选择起始场景</label>
            <select
              className="w-full bg-white/10 border border-white/20 text-white rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-white/50"
              value={selectedSceneId}
              onChange={(e) => setSelectedSceneId(e.target.value)}
            >
              <option value="" className="text-slate-800">-- 请选择 --</option>
              {scenes.map(s => (
                <option key={s.id} value={s.id} className="text-slate-800">{s.name}</option>
              ))}
            </select>
            
            {/* 双模式按钮布局 */}
            <div className="grid grid-cols-2 gap-3 mt-4">
              <Button
                variant="secondary"
                size="lg"
                className="font-bold bg-white text-slate-700 hover:bg-slate-50"
                onClick={handleGenerateStory}
                disabled={!selectedSceneId || scenes.length === 0 || layers.length === 0 || plays.length === 0}
              >
                <FileText size={18} className="mr-2" />
                一键生成流程
                <div className="text-xs opacity-70 mt-1">快速模式</div>
              </Button>
              
              <Button
                variant="secondary"
                size="lg"
                className="font-bold bg-white text-blue-800 hover:bg-blue-50 border border-blue-200"
                onClick={startInteractiveMode}
                disabled={!selectedSceneId || scenes.length === 0 || layers.length === 0 || plays.length === 0}
              >
                <MapPin size={18} className="mr-2" />
                开启剧情走向
                <div className="text-xs opacity-70 mt-1">沉浸模式</div>
              </Button>
            </div>
          </div>
        </div>

      {/* V1.3.18 修复：移除条件判断，始终允许点击 openHistory，确保弹出模态框 */}
      <Card 
        className={`bg-slate-100 p-3 flex items-center justify-between cursor-pointer hover:bg-slate-200`} 
        onClick={openHistory} // <-- 无条件触发 openHistory
      >
          <div className="flex items-center space-x-2 text-slate-700">
            <History size={16}/>
            <span className="font-semibold text-sm">历史记录</span>
          </div>
          <Badge color="slate">{generatedHistory.length} 条</Badge>
      </Card>


      {/* 生成结果显示 */}
      {generatedStory.length > 0 && (
        <div className="animate-in fade-in slide-in-from-bottom-5 duration-500">
          <div className="flex justify-between items-center mb-2 px-1">
            <h3 className="font-bold text-slate-800">当前生成结果</h3>
            <div className="flex space-x-2">
              {/* V1.3.2 新增: 为当前结果添加复制按钮 */}
              <button
                onClick={() => copyStoryToClipboard(generatedStory, 'current')}
                className="text-xs text-indigo-600 font-medium hover:underline flex items-center"
              >
                <Copy size={14} className="mr-1"/> 复制文本
              </button>
              <button
                  onClick={() => exportStoryToTxt(generatedStory, `当前故事`)}
                  className="text-xs text-indigo-600 font-medium hover:underline flex items-center"
              >
                <Download size={14} className="mr-1"/> 导出为 TXT
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {generatedStory.map((item, idx) => {
              if (item.type === 'header') return (
                <div key={idx} className="bg-slate-800 text-white p-4 rounded-xl shadow-md">
                  <div className="text-xs opacity-50 uppercase tracking-widest mb-1">SCENE</div>
                  <div className="text-xl font-bold">{item.text.replace('场景：', '')}</div>
                  <div className="text-sm opacity-80 mt-1">{item.desc}</div>
                </div>
              );
              if (item.type === 'play') return (
                <div key={idx} className="relative pl-6 border-l-2 border-slate-200 py-1">
                   <div className="absolute -left-[9px] top-3 w-4 h-4 rounded-full bg-indigo-500 border-2 border-white"></div>
                   <div className="text-xs font-bold text-indigo-600 mb-1">{item.layerName}</div>
                   <h4 className="font-bold text-slate-800">{item.title}</h4>
                   <p className="text-sm text-slate-600">{item.content}</p>
                   <div className="mt-1 text-xs bg-slate-100 inline-block px-2 py-1 rounded text-slate-500">
                     结果: {item.result}
                   </div>
                </div>
              );
              if (item.type === 'command') return (
                <div key={idx} className="ml-6 bg-amber-50 border border-amber-100 p-3 rounded-lg my-2">
                  <div className="flex items-center text-amber-700 text-xs font-bold mb-1">
                    <Zap size={12} className="mr-1"/> 突发指令 ({item.scope})
                  </div>
                  <div className="text-sm font-medium text-slate-800">{item.title}</div>
                  <div className="text-xs text-slate-600">{item.content}</div>
                </div>
              );
              return null;
            })}
            <div className="flex justify-center pt-4 opacity-30 text-2xl">THE END</div>
          </div>
        </div>
      )}
    </div>
    );
  };

  // 新增：剧情走向模式渲染函数
  const renderInteractiveMode = () => {
    const sortedLayers = [...layers].sort((a, b) => a.sequence - b.sequence);
    const currentLayer = sortedLayers[currentLayerIndex];
    const { plays: candidatePlays, commands: candidateCommands } = getCandidatesForCurrentLayer();
    
    return (
      <div className="space-y-6 pb-24">
        {/* 进度条 */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-xl shadow-lg">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-lg font-bold flex items-center">
              <MapPin size={18} className="mr-2" />
              第 {currentLayerIndex + 1} / {sortedLayers.length} 幕
            </h3>
            <button
              onClick={exitInteractiveMode}
              className="text-white/80 hover:text-white text-sm"
            >
              <X size={18} />
            </button>
          </div>
          <div className="text-sm opacity-90 font-medium">
            {currentLayer ? currentLayer.layer_name : '未知层级'}
          </div>
          <div className="w-full bg-white/20 rounded-full h-2 mt-2">
            <div 
              className="bg-white rounded-full h-2 transition-all duration-300"
              style={{ width: `${((currentLayerIndex + 1) / sortedLayers.length) * 100}%` }}
            />
          </div>
        </div>

        {/* 故事进度显示 */}
        <div className="space-y-3">
          {interactiveStory.map((item, idx) => {
            if (item.type === 'header') return (
              <div key={idx} className="bg-slate-800 text-white p-4 rounded-xl shadow-md">
                <div className="text-xs opacity-50 uppercase tracking-widest mb-1">SCENE</div>
                <div className="text-xl font-bold">{item.text.replace('场景：', '')}</div>
                <div className="text-sm opacity-80 mt-1">{item.desc}</div>
              </div>
            );
            if (item.type === 'play') return (
              <div key={idx} className="relative pl-6 border-l-2 border-slate-200 py-1">
                <div className="absolute -left-[9px] top-3 w-4 h-4 rounded-full bg-indigo-500 border-2 border-white"></div>
                <div className="text-xs font-bold text-indigo-600 mb-1">{item.layerName}</div>
                <h4 className="font-bold text-slate-800">{item.title}</h4>
                <p className="text-sm text-slate-600">{item.content}</p>
                <div className="mt-1 text-xs bg-slate-100 inline-block px-2 py-1 rounded text-slate-500">
                  结果: {item.result}
                </div>
              </div>
            );
            if (item.type === 'command') return (
              <div key={idx} className="ml-6 bg-amber-50 border border-amber-100 p-3 rounded-lg my-2">
                <div className="flex items-center text-amber-700 text-xs font-bold mb-1">
                  <Zap size={12} className="mr-1" /> 突发指令 ({item.scope})
                </div>
                <div className="text-sm font-medium text-slate-800">{item.title}</div>
                <div className="text-xs text-slate-600">{item.content}</div>
              </div>
            );
            return null;
          })}
        </div>

        {/* 候选选项 */}
        {(candidatePlays.length > 0 || candidateCommands.length > 0) && (
          <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4">选择你的行动</h3>
            
            {/* 玩法选项 */}
            {candidatePlays.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-bold text-indigo-600 mb-3">玩法选项</h4>
                <div className="space-y-3">
                  {candidatePlays.map(play => (
                    <div key={play.id} className="border border-slate-200 rounded-lg p-4 hover:border-indigo-300 transition-colors">
                      <label className="flex items-start cursor-pointer">
                        <input
                          type="checkbox"
                          className="mt-1 mr-3 w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
                          checked={selectedChoices.includes(play.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedChoices(prev => [...prev, play.id]);
                            } else {
                              setSelectedChoices(prev => prev.filter(id => id !== play.id));
                            }
                          }}
                        />
                        <div className="flex-1">
                          <div className="font-medium text-slate-800">{play.name}</div>
                          <div className="text-sm text-slate-600 mt-1">{play.description}</div>
                          <div className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded mt-2 inline-block">
                            结果: {play.result}
                          </div>
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 突发指令 */}
            {candidateCommands.length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-bold text-amber-600 mb-3 flex items-center">
                  <Zap size={14} className="mr-1" /> 突发指令
                </h4>
                <div className="space-y-3">
                  {candidateCommands.map(cmd => (
                    <div key={cmd.id} className="border border-amber-200 bg-amber-50 rounded-lg p-4 hover:border-amber-300 transition-colors">
                      <label className="flex items-start cursor-pointer">
                        <input
                          type="checkbox"
                          className="mt-1 mr-3 w-4 h-4 text-amber-600 rounded focus:ring-amber-500"
                          checked={selectedCommands.includes(cmd.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedCommands(prev => [...prev, cmd.id]);
                            } else {
                              setSelectedCommands(prev => prev.filter(id => id !== cmd.id));
                            }
                          }}
                        />
                        <div className="flex-1">
                          <div className="font-medium text-slate-800">{cmd.name}</div>
                          <div className="text-sm text-slate-600 mt-1">{cmd.description}</div>
                          <div className="text-xs bg-amber-100 text-amber-700 px-2 py-1 rounded mt-2 inline-block">
                            作用域: {cmd.scope_type}
                          </div>
                        </div>
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 操作按钮 */}
            <div className="flex space-x-3">
              <Button
                variant="primary"
                size="lg"
                className="flex-1 font-bold"
                onClick={handleInteractiveChoice}
                disabled={selectedChoices.length === 0 && selectedCommands.length === 0}
              >
                确认选择
                <div className="text-xs opacity-70 mt-1">
                  已选择 {selectedChoices.length + selectedCommands.length} 项
                </div>
              </Button>
            </div>
          </div>
        )}

        {/* 故事结束提示 */}
        {currentLayerIndex >= sortedLayers.length - 1 && candidatePlays.length === 0 && candidateCommands.length === 0 && (
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-6 rounded-xl shadow-lg text-center">
            <h3 className="text-2xl font-bold mb-2">故事结束</h3>
            <p className="opacity-90">恭喜！你完成了整个剧情走向</p>
            <div className="flex justify-center mt-4">
              <Button
                variant="secondary"
                size="lg"
                className="bg-white text-green-600 hover:bg-green-50"
                onClick={() => {
                  setGeneratedHistory(prev => [{
                    timestamp: Date.now(),
                    sceneName: `${currentScene.name} (剧情走向)`,
                    story: interactiveStory,
                  }, ...prev]);
                  showToast("故事已保存到历史记录");
                  setInteractiveMode(false);
                }}
              >
                保存到历史记录
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderSettings = () => (
    <div className="space-y-6 pb-24">
      <div className="flex justify-between items-center mb-4 px-1">
        <h2 className="text-xl font-bold text-slate-800 flex items-center"><Settings size={22} className="mr-2"/> 数据与设置</h2>
      </div>

      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><HardDrive size={18} className="mr-2 text-indigo-600"/> 数据统计</h3>
        <p className="text-sm text-slate-500 mt-2">当前数据存储于本地浏览器。</p>
        <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
          <div className="p-3 bg-slate-50 rounded-lg">场景: <Badge color="blue">{scenes.length}</Badge></div>
          <div className="p-3 bg-slate-50 rounded-lg">层级: <Badge color="green">{layers.length}</Badge></div>
          <div className="p-3 bg-slate-50 rounded-lg">玩法: <Badge color="purple">{plays.length}</Badge></div>
          <div className="p-3 bg-slate-50 rounded-lg">指令: <Badge color="orange">{commands.length}</Badge></div>
        </div>
        
        {/* 数据保存状态显示 */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-blue-800">自动保存状态</span>
            <div className="flex items-center space-x-2">
              {isSaving ? (
                <span className="text-xs text-blue-600">保存中...</span>
              ) : lastSaveTime ? (
                <span className="text-xs text-green-600">
                  已保存 {new Date(lastSaveTime).toLocaleTimeString()}
                </span>
              ) : (
                <span className="text-xs text-slate-500">未保存</span>
              )}
              <div className={`w-2 h-2 rounded-full ${isSaving ? 'bg-blue-500 animate-pulse' : 'bg-green-500'}`}></div>
            </div>
          </div>
        </div>
      </Card>

      {/* V1.3.15 新增: 相关下载 */}
      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><Download size={18} className="mr-2 text-indigo-600"/> 相关下载 (初始化数据)</h3>
        <p className="text-sm text-slate-500 mt-2">
            点击下载相关的初始化数据和资源文件，方便快速上手。
        </p>
        <Button 
            onClick={() => window.open('https://cowtransfer.com/s/67985f57bac44f', '_blank')} 
            size="md" 
            className="w-full mt-4"
            variant="secondary"
        >
            <Download size={16} className="mr-2"/> 相关下载
        </Button>
      </Card>

      {/* V1.3.15 新增: 分享剧本 */}
      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><Link size={18} className="mr-2 text-indigo-600"/> 分享剧本</h3>
        <p className="text-sm text-slate-500 mt-2">
            前往剧本分享页面，查看或分享更多有趣的故事剧本。
        </p>
        <Button 
            onClick={() => window.open('https://c.wss.pet/s/iqmbgn2ipoz', '_blank')} 
            size="md" 
            className="w-full mt-4"
            variant="secondary"
        >
            <Share2 size={16} className="mr-2"/> 分享剧本
        </Button>
      </Card>

      {/* V1.3.15 新增: 反馈留言 */}
      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><MessageSquare size={18} className="mr-2 text-indigo-600"/> 反馈留言</h3>
        <p className="text-sm text-slate-500 mt-2">
            提交您的使用反馈、建议或报告遇到的问题。
        </p>
        <Button 
            onClick={() => window.open('https://simplefeedback.app/feedback/kaMxISU-Nvem', '_blank')} 
            size="md" 
            className="w-full mt-4"
            variant="secondary"
        >
            <MessageSquare size={16} className="mr-2"/> 反馈留言
        </Button>
      </Card>

      {/* V1.3.8 修改: 流程分享/数据链接导出 */}
      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><Link size={18} className="mr-2 text-indigo-600"/> 流程分享 / 备份链接</h3>
        <p className="text-sm text-slate-500 mt-2">
            点击下方按钮，将所有配置数据（场景、层级、玩法、指令）生成为一个 **Data URI 链接** 并自动复制到剪贴板。该链接可用于分享或跨设备导入。
        </p>
        <Button onClick={handleExportDataLink} size="md" className="w-full mt-4" variant="secondary">
            <Copy size={16} className="mr-2"/> 复制数据共享链接
        </Button>
      </Card>

      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><Download size={18} className="mr-2 text-indigo-600"/> 导入/导出 (JSON)</h3>
        <p className="text-sm text-slate-500 mt-2">将所有数据 (场景、层级、玩法、指令) 导出为 JSON 文件，或从 JSON 文件导入。</p>

        <div className="flex space-x-3 mt-4">
          <Button variant="secondary" size="md" onClick={() => {
            const data = { scenes, layers, plays, commands };
            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `text_game_weaver_data_${Date.now()}.json`;
            a.click();
            URL.revokeObjectURL(url); // 导出 JSON 时清理 blob
            showToast("数据已导出");
          }}>
            <Download size={16} className="mr-2"/> 导出 JSON
          </Button>
          <label htmlFor="file-upload" className="flex items-center justify-center rounded-lg font-medium transition-colors active:scale-95 bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 px-4 py-2 text-sm cursor-pointer">
            <Upload size={16} className="mr-2"/> 导入 JSON
            <input
              id="file-upload"
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = (event) => {
                  try {
                    const data = JSON.parse(event.target.result);
                    if (data.scenes && data.layers && data.plays && data.commands) {
                      setScenes(data.scenes);
                      setLayers(data.layers);
                      setPlays(data.plays);
                      setCommands(data.commands);
                      showToast("数据导入成功");
                      setGeneratedHistory([]); // 清空历史记录以保持数据一致性
                    } else {
                      showToast("JSON 文件格式不正确", "error");
                    }
                  } catch (error) {
                    showToast("文件解析失败: 无效的 JSON", "error");
                  }
                };
                reader.readAsText(file);
              }}
            />
          </label>
        </div>
      </Card>

      <Card>
        <h3 className="font-bold text-slate-800 flex items-center"><Trash2 size={18} className="mr-2 text-red-600"/> 数据管理</h3>
        <p className="text-sm text-slate-500 mt-2">
          管理本地存储数据，包括手动保存和清理功能。
        </p>
        
        <div className="space-y-3 mt-4">
          <Button
            variant="secondary"
            size="md"
            className="w-full"
            onClick={() => {
              if (saveAllData()) {
                showToast("手动保存成功", "success");
              } else {
                showToast("手动保存失败", "error");
              }
            }}
            disabled={isSaving}
          >
            <Save size={16} className="mr-2" />
            {isSaving ? "保存中..." : "立即保存数据"}
          </Button>
          
          <Button
            variant="lightDanger"
            size="md"
            className="w-full"
            onClick={() => {
              if (confirm("确定要清空所有本地数据吗？此操作不可撤销，包括场景、层级、玩法、指令、历史记录等所有数据。")) {
                clearAllData();
                setScenes(INITIAL_SCENES);
                setLayers(INITIAL_LAYERS);
                setPlays(INITIAL_PLAYS);
                setCommands(INITIAL_COMMANDS);
                setGeneratedHistory([]);
                setSelectedSceneId("");
                setActiveTab("generator");
                setGeneratedStory([]);
                showToast("所有数据已清空", "success");
              }
            }}
          >
            <Trash2 size={16} className="mr-2" />
            清空所有数据
          </Button>
        </div>
      </Card>
    </div>
  );


  // --- 主渲染逻辑 ---
  const modalProps = modalOpen ? renderModalContent() : { title: "", content: null };

  return (
    <div className="min-h-screen bg-slate-50 antialiased font-inter">
      {/* V1.3.19 修复：确保 renderConfirmModal 渲染在最前面 */}
      {renderConfirmModal()}

      <main className="max-w-xl mx-auto p-4 pb-20">
        <h1 className="text-2xl font-black text-slate-900 mb-6 flex items-center">
          <FileText size={28} className="mr-2 text-indigo-600"/>
          剧情织造机 V1.3.19 (定制版)
        </h1>

        {/* 内容区域 - 修复Tab命名不一致问题 */}
        <div className="mt-4">
          {activeTab === 'generator' && renderGenerator()}
          {activeTab === 'scenes' && renderSceneList()}
          {activeTab === 'layers' && renderLayerList()}
          {activeTab === 'plays' && renderPlayList()}
          {activeTab === 'commands' && renderCommandList()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </main>

      {/* --- Bottom Navigation --- */}
      <nav className="fixed bottom-0 w-full max-w-xl left-1/2 -translate-x-1/2 bg-white border-t flex justify-around items-center h-20 px-2 shadow-[0_-5px_20px_rgba(0,0,0,0.05)] z-40">
        {[
          { id: 'generator', icon: Play, label: '生成' },
          { id: 'scenes', icon: MapPin, label: '场景' }, 
          { id: 'layers', icon: Layers, label: '层级' },
          { id: 'plays', icon: BookOpen, label: '玩法' },
          { id: 'commands', icon: Zap, label: '指令' },
          { id: 'settings', icon: Settings, label: '设置' },
        ].map(item => {
          const handleTabClick = () => {
            if (interactiveMode && item.id !== 'generator') {
              if (confirm("剧情走向进行中，切换Tab将丢失当前进度。确定要继续吗？")) {
                setInteractiveMode(false);
                setCurrentLayerIndex(0);
                setInteractiveStory([]);
                setSelectedChoices([]);
                setSelectedCommands([]);
                setCurrentScene(null);
                setActiveTab(item.id);
              }
            } else {
              setActiveTab(item.id);
            }
          };

          return (
            <NavButton
              key={item.id}
              icon={item.icon}
              label={item.label}
              active={activeTab === item.id}
              onClick={handleTabClick}
              primary={item.id === 'generator'}
            />
          );
        })}
      </nav>

      {/* 新增/编辑/批量/历史 模态框 (默认 zIndex=50) */}
      <Modal
        isOpen={modalOpen}
        onClose={() => {
            setModalOpen(false);
            // 确保关闭模态框时清空批量文本和历史编辑状态
            setBatchText(""); 
            setEditingHistoryId(null);
            setTempHistoryTitle('');
        }}
        title={modalProps.title}
      >
        {modalProps.content}
      </Modal>

      {/* 提示条 */}
      <Snackbar message={toast.msg} type={toast.type} onClose={() => setToast({ msg: "", type: "success" })} />
    </div>
  );
}